Changelog for extract-dtb
=========================

1.2.4 (unreleased)
------------------

- Nothing changed yet.


1.2.3 (2022-09-29)
------------------

- Sanitize output filename by removing newlines and special characters (#14).


1.2.2 (2021-03-19)
------------------

- Fixed typo: safe_output_path directly receives output_dir argument, not args


1.2.1 (2021-03-05)
------------------

- Fix broken release


1.2 (2021-03-05)
----------------

- Support extracting DTBs with subfolders
- Replace slash with underscore in dtb filename

1.1 (2017-08-21)
----------------

- Fixed bug where one dtb was not being extracted
- Show information about dumped dtbs and their position in the image
- Add DTB name to the filename and add leading zero to filename numbering
- Added --version argument

1.0 (2017-06-25)
----------------

- First release
